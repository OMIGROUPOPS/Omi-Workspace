import { SUPPORTED_SPORTS } from '../../../../../../lib/edge/utils/constants';
import { createOddsApiClient } from '../../../../../../lib/edge/api/odds-api';
import { removeVigFromAmerican } from '../../../../../../lib/edge/utils/odds-math';
import Link from 'next/link';
import { GameDetailClient } from '../../../../../../components/edge/GameDetailClient';

function generateMockEdge(id: string, offset: number = 0): number {
  const seed = id.split('').reduce((a, c) => a + c.charCodeAt(0), 0) + offset;
  const x = Math.sin(seed) * 10000;
  return (x - Math.floor(x) - 0.5) * 0.08;
}

interface PageProps {
  params: Promise<{ id: string }>;
}

export default async function GameDetailPage({ params }: PageProps) {
  const { id: gameId } = await params;

  const client = createOddsApiClient(process.env.ODDS_API_KEY!);
  
  const sportsToSearch = ['americanfootball_nfl', 'basketball_nba', 'americanfootball_ncaaf', 'basketball_ncaab', 'icehockey_nhl'];
  
  let sportKey: string = '';
  let gameInfo: any = null;

  for (const sport of sportsToSearch) {
    try {
      const events = await client.fetchEvents(sport);
      const found = events.find((e) => e.id === gameId);
      if (found) {
        sportKey = sport;
        gameInfo = found;
        break;
      }
    } catch (e) {
      continue;
    }
  }

  if (!sportKey || !gameInfo) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Game not found</h1>
          <Link href="/edge/portal/sports" className="text-emerald-400 hover:underline">
            Back to sports
          </Link>
        </div>
      </div>
    );
  }

  // ALL available markets from The Odds API
  const allMarkets = [
    // Full game
    'h2h', 'spreads', 'totals',
    // 1st half
    'h2h_h1', 'spreads_h1', 'totals_h1',
    // 2nd half
    'h2h_h2', 'spreads_h2', 'totals_h2',
    // Quarters
    'h2h_q1', 'spreads_q1', 'totals_q1',
    'h2h_q2', 'spreads_q2', 'totals_q2',
    'h2h_q3', 'spreads_q3', 'totals_q3',
    'h2h_q4', 'spreads_q4', 'totals_q4',
    // Alternates
    'alternate_spreads', 'alternate_totals',
    // Team totals
    'team_totals',
    // Player props - passing
    'player_pass_tds', 'player_pass_yds', 'player_pass_completions', 
    'player_pass_attempts', 'player_pass_interceptions',
    // Player props - rushing
    'player_rush_yds', 'player_rush_attempts',
    // Player props - receiving
    'player_receptions', 'player_reception_yds',
    // Player props - scoring
    'player_anytime_td', 'player_last_td',
    // Player props - kicking
    'player_kicking_points', 'player_field_goals',
    // Player props - defense
    'player_tackles_assists'
  ].join(',');

  let gameData: any = null;
  try {
    gameData = await client.fetchEventOdds(sportKey, gameId, {
      regions: 'us',
      markets: allMarkets,
      oddsFormat: 'american',
    });
  } catch (e) {
    console.error('Failed to fetch event odds:', e);
  }

  if (!gameData) {
    return (
      <div className="min-h-screen bg-zinc-950 text-zinc-100 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-2">Failed to load odds</h1>
          <Link href={`/edge/portal/sports/${sportKey}`} className="text-emerald-400 hover:underline">
            Back to games
          </Link>
        </div>
      </div>
    );
  }

  const sportInfo = SUPPORTED_SPORTS.find((s) => s.key === sportKey);

  const processTwoWayMarket = (market: any, homeTeam: string, awayTeam: string, offsetBase: number) => {
    const home = market.outcomes.find((o: any) => o.name === homeTeam);
    const away = market.outcomes.find((o: any) => o.name === awayTeam);
    if (!home || !away) return null;
    
    const { true1, true2 } = removeVigFromAmerican(home.price, away.price);
    return {
      home: { name: homeTeam, line: home.point, price: home.price, implied: true1, edge: generateMockEdge(gameId, offsetBase) },
      away: { name: awayTeam, line: away.point, price: away.price, implied: true2, edge: generateMockEdge(gameId, offsetBase + 1) },
    };
  };

  const processTotalsMarket = (market: any, offsetBase: number) => {
    const over = market.outcomes.find((o: any) => o.name === 'Over');
    const under = market.outcomes.find((o: any) => o.name === 'Under');
    if (!over || !under) return null;
    
    const { true1, true2 } = removeVigFromAmerican(over.price, under.price);
    return {
      line: over.point,
      over: { price: over.price, implied: true1, edge: generateMockEdge(gameId, offsetBase) },
      under: { price: under.price, implied: true2, edge: generateMockEdge(gameId, offsetBase + 1) },
    };
  };

  const processTeamTotals = (market: any, homeTeam: string, awayTeam: string, offsetBase: number) => {
    const result: any = {};
    
    const homeOver = market.outcomes.find((o: any) => o.description === homeTeam && o.name === 'Over');
    const homeUnder = market.outcomes.find((o: any) => o.description === homeTeam && o.name === 'Under');
    const awayOver = market.outcomes.find((o: any) => o.description === awayTeam && o.name === 'Over');
    const awayUnder = market.outcomes.find((o: any) => o.description === awayTeam && o.name === 'Under');
    
    if (homeOver && homeUnder) {
      const { true1, true2 } = removeVigFromAmerican(homeOver.price, homeUnder.price);
      result.home = {
        team: homeTeam,
        line: homeOver.point,
        over: { price: homeOver.price, implied: true1, edge: generateMockEdge(gameId, offsetBase) },
        under: { price: homeUnder.price, implied: true2, edge: generateMockEdge(gameId, offsetBase + 1) },
      };
    }
    
    if (awayOver && awayUnder) {
      const { true1, true2 } = removeVigFromAmerican(awayOver.price, awayUnder.price);
      result.away = {
        team: awayTeam,
        line: awayOver.point,
        over: { price: awayOver.price, implied: true1, edge: generateMockEdge(gameId, offsetBase + 2) },
        under: { price: awayUnder.price, implied: true2, edge: generateMockEdge(gameId, offsetBase + 3) },
      };
    }
    
    return Object.keys(result).length > 0 ? result : null;
  };

  const processPlayerProps = (markets: any[], offsetBase: number) => {
    const props: any[] = [];
    const propMarkets = markets.filter((m: any) => m.key.startsWith('player_'));
    
    propMarkets.forEach((market: any, mIdx: number) => {
      const playerMap = new Map<string, any[]>();
      
      market.outcomes.forEach((outcome: any) => {
        const playerName = outcome.description || 'Unknown';
        if (!playerMap.has(playerName)) playerMap.set(playerName, []);
        playerMap.get(playerName)!.push(outcome);
      });

      playerMap.forEach((outcomes, playerName) => {
        const over = outcomes.find((o: any) => o.name === 'Over');
        const under = outcomes.find((o: any) => o.name === 'Under');
        const yes = outcomes.find((o: any) => o.name === 'Yes');
        
        if (over && under) {
          const { true1, true2 } = removeVigFromAmerican(over.price, under.price);
          props.push({
            player: playerName,
            market: market.key.replace('player_', '').replace(/_/g, ' '),
            marketKey: market.key,
            line: over.point,
            over: { price: over.price, implied: true1, edge: generateMockEdge(gameId, offsetBase + mIdx * 10) },
            under: { price: under.price, implied: true2, edge: generateMockEdge(gameId, offsetBase + mIdx * 10 + 1) },
          });
        } else if (yes) {
          props.push({
            player: playerName,
            market: market.key.replace('player_', '').replace(/_/g, ' '),
            marketKey: market.key,
            line: null,
            yes: { price: yes.price, edge: generateMockEdge(gameId, offsetBase + mIdx * 10) },
          });
        }
      });
    });

    return props;
  };

  const processAlternates = (markets: any[], homeTeam: string, awayTeam: string, offsetBase: number) => {
    const alternates: any = { spreads: [], totals: [] };
    
    const altSpreads = markets.find((m: any) => m.key === 'alternate_spreads');
    const altTotals = markets.find((m: any) => m.key === 'alternate_totals');
    
    if (altSpreads) {
      altSpreads.outcomes.forEach((outcome: any, idx: number) => {
        alternates.spreads.push({
          team: outcome.name,
          line: outcome.point,
          price: outcome.price,
          edge: generateMockEdge(gameId, offsetBase + idx),
        });
      });
    }
    
    if (altTotals) {
      altTotals.outcomes.forEach((outcome: any, idx: number) => {
        alternates.totals.push({
          type: outcome.name,
          line: outcome.point,
          price: outcome.price,
          edge: generateMockEdge(gameId, offsetBase + 500 + idx),
        });
      });
    }
    
    return alternates;
  };

  const processedBookmakers: Record<string, any> = {};
  
  gameData.bookmakers?.forEach((bookmaker: any, bookIndex: number) => {
    const marketGroups: any = {
      fullGame: {},
      firstHalf: {},
      secondHalf: {},
      q1: {}, q2: {}, q3: {}, q4: {},
      teamTotals: null,
      alternates: { spreads: [], totals: [] },
      playerProps: [],
    };
    
    let offset = bookIndex * 1000;
    
    bookmaker.markets?.forEach((market: any) => {
      offset += 10;
      
      switch (market.key) {
        // Full game
        case 'h2h': marketGroups.fullGame.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads': marketGroups.fullGame.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals': marketGroups.fullGame.totals = processTotalsMarket(market, offset); break;
        // 1st half
        case 'h2h_h1': marketGroups.firstHalf.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_h1': marketGroups.firstHalf.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_h1': marketGroups.firstHalf.totals = processTotalsMarket(market, offset); break;
        // 2nd half
        case 'h2h_h2': marketGroups.secondHalf.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_h2': marketGroups.secondHalf.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_h2': marketGroups.secondHalf.totals = processTotalsMarket(market, offset); break;
        // Quarters
        case 'h2h_q1': marketGroups.q1.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_q1': marketGroups.q1.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_q1': marketGroups.q1.totals = processTotalsMarket(market, offset); break;
        case 'h2h_q2': marketGroups.q2.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_q2': marketGroups.q2.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_q2': marketGroups.q2.totals = processTotalsMarket(market, offset); break;
        case 'h2h_q3': marketGroups.q3.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_q3': marketGroups.q3.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_q3': marketGroups.q3.totals = processTotalsMarket(market, offset); break;
        case 'h2h_q4': marketGroups.q4.h2h = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'spreads_q4': marketGroups.q4.spreads = processTwoWayMarket(market, gameData.home_team, gameData.away_team, offset); break;
        case 'totals_q4': marketGroups.q4.totals = processTotalsMarket(market, offset); break;
        // Team totals
        case 'team_totals': marketGroups.teamTotals = processTeamTotals(market, gameData.home_team, gameData.away_team, offset); break;
      }
    });

    marketGroups.alternates = processAlternates(bookmaker.markets || [], gameData.home_team, gameData.away_team, offset);
    marketGroups.playerProps = processPlayerProps(bookmaker.markets || [], offset);

    processedBookmakers[bookmaker.key] = { name: bookmaker.title, marketGroups };
  });

  const availableBooks = Object.keys(processedBookmakers);

  const hasFirstHalf = Object.values(processedBookmakers).some((b: any) => b.marketGroups.firstHalf.h2h || b.marketGroups.firstHalf.spreads || b.marketGroups.firstHalf.totals);
  const hasSecondHalf = Object.values(processedBookmakers).some((b: any) => b.marketGroups.secondHalf.h2h || b.marketGroups.secondHalf.spreads || b.marketGroups.secondHalf.totals);
  const hasQ1 = Object.values(processedBookmakers).some((b: any) => b.marketGroups.q1.h2h || b.marketGroups.q1.spreads || b.marketGroups.q1.totals);
  const hasQ2 = Object.values(processedBookmakers).some((b: any) => b.marketGroups.q2.h2h || b.marketGroups.q2.spreads || b.marketGroups.q2.totals);
  const hasQ3 = Object.values(processedBookmakers).some((b: any) => b.marketGroups.q3.h2h || b.marketGroups.q3.spreads || b.marketGroups.q3.totals);
  const hasQ4 = Object.values(processedBookmakers).some((b: any) => b.marketGroups.q4.h2h || b.marketGroups.q4.spreads || b.marketGroups.q4.totals);
  const hasProps = Object.values(processedBookmakers).some((b: any) => b.marketGroups.playerProps?.length > 0);
  const hasAlts = Object.values(processedBookmakers).some((b: any) => b.marketGroups.alternates?.spreads?.length > 0 || b.marketGroups.alternates?.totals?.length > 0);
  const hasTeamTotals = Object.values(processedBookmakers).some((b: any) => b.marketGroups.teamTotals);

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Link href={`/edge/portal/sports/${sportKey}`} className="text-zinc-400 hover:text-zinc-200 transition-colors">
            ← Back
          </Link>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-lg p-6 mb-6">
          <div className="flex items-center gap-3">
            <span className="text-2xl">{sportInfo?.icon || '🏈'}</span>
            <div>
              <h1 className="text-xl font-bold">{gameData.away_team} @ {gameData.home_team}</h1>
              <p className="text-zinc-400 text-sm">
                {new Date(gameData.commence_time).toLocaleString('en-US', {
                  weekday: 'long', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit',
                })}
              </p>
            </div>
          </div>
        </div>

        <GameDetailClient 
          gameData={{ id: gameData.id, homeTeam: gameData.home_team, awayTeam: gameData.away_team, sportKey }}
          bookmakers={processedBookmakers}
          availableBooks={availableBooks}
          availableTabs={{ 
            fullGame: true, 
            firstHalf: hasFirstHalf, 
            secondHalf: hasSecondHalf,
            q1: hasQ1, q2: hasQ2, q3: hasQ3, q4: hasQ4, 
            props: hasProps, 
            alternates: hasAlts,
            teamTotals: hasTeamTotals,
          }}
        />
      </div>
    </div>
  );
}