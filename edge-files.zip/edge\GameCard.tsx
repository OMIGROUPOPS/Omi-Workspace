'use client';

import Link from 'next/link';
import { formatOdds, formatSpread } from '@/lib/edge/utils/odds-math';
import type { Game, ConsensusOdds, EdgeCalculation } from '@/types/edge';

const NFL_TEAMS: Record<string, string> = {
  'Arizona Cardinals': 'ari',
  'Atlanta Falcons': 'atl',
  'Baltimore Ravens': 'bal',
  'Buffalo Bills': 'buf',
  'Carolina Panthers': 'car',
  'Chicago Bears': 'chi',
  'Cincinnati Bengals': 'cin',
  'Cleveland Browns': 'cle',
  'Dallas Cowboys': 'dal',
  'Denver Broncos': 'den',
  'Detroit Lions': 'det',
  'Green Bay Packers': 'gb',
  'Houston Texans': 'hou',
  'Indianapolis Colts': 'ind',
  'Jacksonville Jaguars': 'jax',
  'Kansas City Chiefs': 'kc',
  'Las Vegas Raiders': 'lv',
  'Los Angeles Chargers': 'lac',
  'Los Angeles Rams': 'lar',
  'Miami Dolphins': 'mia',
  'Minnesota Vikings': 'min',
  'New England Patriots': 'ne',
  'New Orleans Saints': 'no',
  'New York Giants': 'nyg',
  'New York Jets': 'nyj',
  'Philadelphia Eagles': 'phi',
  'Pittsburgh Steelers': 'pit',
  'San Francisco 49ers': 'sf',
  'Seattle Seahawks': 'sea',
  'Tampa Bay Buccaneers': 'tb',
  'Tennessee Titans': 'ten',
  'Washington Commanders': 'wsh',
};

const NBA_TEAMS: Record<string, string> = {
  'Atlanta Hawks': 'atl',
  'Boston Celtics': 'bos',
  'Brooklyn Nets': 'bkn',
  'Charlotte Hornets': 'cha',
  'Chicago Bulls': 'chi',
  'Cleveland Cavaliers': 'cle',
  'Dallas Mavericks': 'dal',
  'Denver Nuggets': 'den',
  'Detroit Pistons': 'det',
  'Golden State Warriors': 'gs',
  'Houston Rockets': 'hou',
  'Indiana Pacers': 'ind',
  'LA Clippers': 'lac',
  'Los Angeles Clippers': 'lac',
  'Los Angeles Lakers': 'lal',
  'LA Lakers': 'lal',
  'Memphis Grizzlies': 'mem',
  'Miami Heat': 'mia',
  'Milwaukee Bucks': 'mil',
  'Minnesota Timberwolves': 'min',
  'New Orleans Pelicans': 'no',
  'New York Knicks': 'ny',
  'Oklahoma City Thunder': 'okc',
  'Orlando Magic': 'orl',
  'Philadelphia 76ers': 'phi',
  'Phoenix Suns': 'phx',
  'Portland Trail Blazers': 'por',
  'Sacramento Kings': 'sac',
  'San Antonio Spurs': 'sa',
  'Toronto Raptors': 'tor',
  'Utah Jazz': 'utah',
  'Washington Wizards': 'wsh',
};

function getTeamLogo(teamName: string, sportKey: string): string {
  if (sportKey.includes('nfl') || sportKey.includes('americanfootball')) {
    const abbrev = NFL_TEAMS[teamName];
    if (abbrev) return `https://a.espncdn.com/i/teamlogos/nfl/500/${abbrev}.png`;
  }
  if (sportKey.includes('nba') || sportKey.includes('basketball')) {
    const abbrev = NBA_TEAMS[teamName];
    if (abbrev) return `https://a.espncdn.com/i/teamlogos/nba/500/${abbrev}.png`;
  }
  return '';
}

function getEdgeColor(delta: number): string {
  if (delta >= 0.03) return 'text-emerald-400';
  if (delta >= 0.01) return 'text-emerald-300/70';
  if (delta <= -0.03) return 'text-red-400';
  if (delta <= -0.01) return 'text-red-300/70';
  return 'text-zinc-500';
}

function getEdgeBg(delta: number): string {
  if (delta >= 0.03) return 'bg-emerald-500/10 border-emerald-500/30';
  if (delta <= -0.03) return 'bg-red-500/10 border-red-500/30';
  return 'bg-zinc-800/50 border-zinc-700/50';
}

function getMockEdge(gameId: string, offset: number): number {
  const seed = gameId.split('').reduce((a, c) => a + c.charCodeAt(0), 0) + offset;
  const x = Math.sin(seed) * 10000;
  return (x - Math.floor(x) - 0.5) * 0.08;
}

function getTeamAbbrev(teamName: string): string {
  const words = teamName.split(' ');
  if (words.length === 1) return teamName.slice(0, 3).toUpperCase();
  // Return last word (usually the mascot)
  return words[words.length - 1].slice(0, 8);
}

interface GameCardProps {
  game: Game;
  consensus?: ConsensusOdds;
  edge?: EdgeCalculation;
}

export function GameCard({ game, consensus, edge }: GameCardProps) {
  const awayLogo = getTeamLogo(game.awayTeam, game.sportKey || '');
  const homeLogo = getTeamLogo(game.homeTeam, game.sportKey || '');

  const spreadEdgeHome = getMockEdge(game.id, 10);
  const spreadEdgeAway = -spreadEdgeHome;
  const totalEdgeOver = getMockEdge(game.id, 20);
  const totalEdgeUnder = -totalEdgeOver;

  const formatGameTime = (date: Date) => {
    const d = new Date(date);
    return d.toLocaleString('en-US', {
      weekday: 'short',
      hour: 'numeric',
      minute: '2-digit',
    });
  };

  const formatEdge = (delta: number) => {
    const pct = (delta * 100).toFixed(1);
    return delta > 0 ? `+${pct}%` : `${pct}%`;
  };

  return (
    <Link
      href={`/edge/portal/sports/game/${game.id}`}
      className="block bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all"
    >
      {/* Header */}
      <div className="px-3 py-2 bg-zinc-800/50 border-b border-zinc-800 flex justify-between items-center">
        <span className="text-xs text-zinc-400">{formatGameTime(game.commenceTime)}</span>
        {edge && edge.status !== 'pass' && (
          <span className={`text-xs font-medium px-2 py-0.5 rounded ${
            edge.status === 'rare' ? 'bg-purple-500/20 text-purple-400' :
            edge.status === 'strong_edge' ? 'bg-emerald-500/20 text-emerald-400' :
            edge.status === 'edge' ? 'bg-blue-500/20 text-blue-400' :
            'bg-amber-500/20 text-amber-400'
          }`}>
            {edge.status === 'rare' ? '★ RARE' :
             edge.status === 'strong_edge' ? 'STRONG' :
             edge.status === 'edge' ? 'EDGE' : 'WATCH'}
          </span>
        )}
      </div>

      {/* Column Headers */}
      <div className="grid grid-cols-[minmax(100px,1fr),70px,70px,70px] px-3 py-1.5 border-b border-zinc-800/50 gap-1">
        <span className="text-xs text-zinc-500"></span>
        <span className="text-[10px] text-zinc-500 text-center uppercase tracking-wide">Spread</span>
        <span className="text-[10px] text-zinc-500 text-center uppercase tracking-wide">ML</span>
        <span className="text-[10px] text-zinc-500 text-center uppercase tracking-wide">Total</span>
      </div>

      {/* Away Team Row */}
      <div className="grid grid-cols-[minmax(100px,1fr),70px,70px,70px] px-3 py-2 items-center border-b border-zinc-800/30 gap-1">
        <div className="flex items-center gap-2 min-w-0">
          {awayLogo ? (
            <img src={awayLogo} alt="" className="w-6 h-6 object-contain flex-shrink-0" />
          ) : (
            <div className="w-6 h-6 bg-zinc-700 rounded-full flex-shrink-0" />
          )}
          <span className="font-medium text-zinc-100 text-sm truncate">{getTeamAbbrev(game.awayTeam)}</span>
        </div>
        
        {/* Away Spread */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.spreads ? getEdgeBg(spreadEdgeAway) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.spreads ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">
                {formatSpread(-consensus.spreads.line)}
              </div>
              <div className="text-[10px] text-zinc-400">{formatOdds(consensus.spreads.awayPrice)}</div>
              <div className={`text-[10px] ${getEdgeColor(spreadEdgeAway)}`}>
                {formatEdge(spreadEdgeAway)}
              </div>
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>

        {/* Away ML */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.h2h ? getEdgeBg(edge ? -edge.edgeDelta : 0) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.h2h ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">{formatOdds(consensus.h2h.awayPrice)}</div>
              {edge && (
                <div className={`text-[10px] ${getEdgeColor(-edge.edgeDelta)}`}>
                  {formatEdge(-edge.edgeDelta)}
                </div>
              )}
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>

        {/* Over */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.totals ? getEdgeBg(totalEdgeOver) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.totals ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">
                O {consensus.totals.line}
              </div>
              <div className="text-[10px] text-zinc-400">{formatOdds(consensus.totals.overPrice)}</div>
              <div className={`text-[10px] ${getEdgeColor(totalEdgeOver)}`}>
                {formatEdge(totalEdgeOver)}
              </div>
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>
      </div>

      {/* Home Team Row */}
      <div className="grid grid-cols-[minmax(100px,1fr),70px,70px,70px] px-3 py-2 items-center gap-1">
        <div className="flex items-center gap-2 min-w-0">
          {homeLogo ? (
            <img src={homeLogo} alt="" className="w-6 h-6 object-contain flex-shrink-0" />
          ) : (
            <div className="w-6 h-6 bg-zinc-700 rounded-full flex-shrink-0" />
          )}
          <span className="font-medium text-zinc-100 text-sm truncate">{getTeamAbbrev(game.homeTeam)}</span>
        </div>
        
        {/* Home Spread */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.spreads ? getEdgeBg(spreadEdgeHome) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.spreads ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">
                {formatSpread(consensus.spreads.line)}
              </div>
              <div className="text-[10px] text-zinc-400">{formatOdds(consensus.spreads.homePrice)}</div>
              <div className={`text-[10px] ${getEdgeColor(spreadEdgeHome)}`}>
                {formatEdge(spreadEdgeHome)}
              </div>
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>

        {/* Home ML */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.h2h ? getEdgeBg(edge?.edgeDelta || 0) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.h2h ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">{formatOdds(consensus.h2h.homePrice)}</div>
              {edge && (
                <div className={`text-[10px] ${getEdgeColor(edge.edgeDelta)}`}>
                  {formatEdge(edge.edgeDelta)}
                </div>
              )}
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>

        {/* Under */}
        <div className={`text-center py-1 px-1 rounded border ${consensus?.totals ? getEdgeBg(totalEdgeUnder) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
          {consensus?.totals ? (
            <div className="space-y-0.5">
              <div className="text-xs font-medium text-zinc-100 leading-tight">
                U {consensus.totals.line}
              </div>
              <div className="text-[10px] text-zinc-400">{formatOdds(consensus.totals.underPrice)}</div>
              <div className={`text-[10px] ${getEdgeColor(totalEdgeUnder)}`}>
                {formatEdge(totalEdgeUnder)}
              </div>
            </div>
          ) : <span className="text-zinc-600 text-xs">-</span>}
        </div>
      </div>
    </Link>
  );
}