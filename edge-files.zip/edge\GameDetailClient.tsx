'use client';

import { useState, useRef, useEffect } from 'react';
import { formatOdds, formatSpread } from '@/lib/edge/utils/odds-math';

const BOOK_CONFIG: Record<string, { name: string; color: string }> = {
  'fanduel': { name: 'FanDuel', color: '#1493ff' },
  'draftkings': { name: 'DraftKings', color: '#53d337' },
  'betmgm': { name: 'BetMGM', color: '#c4a44d' },
  'caesars': { name: 'Caesars', color: '#00693e' },
  'pointsbetus': { name: 'PointsBet', color: '#e42222' },
  'bovada': { name: 'Bovada', color: '#cc0000' },
  'betonlineag': { name: 'BetOnline', color: '#ff6600' },
  'lowvig': { name: 'LowVig', color: '#6b7280' },
  'mybookieag': { name: 'MyBookie', color: '#1a1a2e' },
  'williamhill_us': { name: 'Caesars', color: '#00693e' },
  'betus': { name: 'BetUS', color: '#0066cc' },
  'betrivers': { name: 'BetRivers', color: '#1a3c6e' },
  'fanatics': { name: 'Fanatics', color: '#00904a' },
};

function getEdgeColor(delta: number): string {
  if (delta >= 0.03) return 'text-emerald-400';
  if (delta >= 0.01) return 'text-emerald-300/70';
  if (delta <= -0.03) return 'text-red-400';
  if (delta <= -0.01) return 'text-red-300/70';
  return 'text-zinc-500';
}

function getEdgeBg(delta: number): string {
  if (delta >= 0.03) return 'bg-emerald-500/10 border-emerald-500/30';
  if (delta <= -0.03) return 'bg-red-500/10 border-red-500/30';
  return 'bg-zinc-800/50 border-zinc-700/50';
}

const formatEdge = (delta: number) => {
  const pct = (delta * 100).toFixed(1);
  return delta > 0 ? `+${pct}%` : `${pct}%`;
};

function MarketSection({ title, markets, homeTeam, awayTeam }: { title: string; markets: any; homeTeam: string; awayTeam: string; }) {
  if (!markets || (!markets.h2h && !markets.spreads && !markets.totals)) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4">
        <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">{title}</h2></div>
        <div className="p-8 text-center"><p className="text-zinc-500">No {title.toLowerCase()} markets available</p></div>
      </div>
    );
  }

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4">
      <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">{title}</h2></div>
      <div className="p-4">
        <div className="grid grid-cols-[1fr,100px,100px,100px] gap-3 mb-3">
          <div></div>
          <div className="text-center text-xs text-zinc-500 uppercase tracking-wide">Spread</div>
          <div className="text-center text-xs text-zinc-500 uppercase tracking-wide">ML</div>
          <div className="text-center text-xs text-zinc-500 uppercase tracking-wide">Total</div>
        </div>
        <div className="grid grid-cols-[1fr,100px,100px,100px] gap-3 mb-3 items-center">
          <div className="font-medium text-zinc-100 text-sm">{awayTeam}</div>
          <div className={`text-center py-2 px-2 rounded border ${markets.spreads ? getEdgeBg(markets.spreads.away.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.spreads ? (<div><div className="text-sm font-medium text-zinc-100">{formatSpread(markets.spreads.away.line)}</div><div className="text-xs text-zinc-400">{formatOdds(markets.spreads.away.price)}</div><div className={`text-xs ${getEdgeColor(markets.spreads.away.edge)}`}>{formatEdge(markets.spreads.away.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
          <div className={`text-center py-2 px-2 rounded border ${markets.h2h ? getEdgeBg(markets.h2h.away.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.h2h ? (<div><div className="text-sm font-medium text-zinc-100">{formatOdds(markets.h2h.away.price)}</div><div className={`text-xs ${getEdgeColor(markets.h2h.away.edge)}`}>{formatEdge(markets.h2h.away.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
          <div className={`text-center py-2 px-2 rounded border ${markets.totals ? getEdgeBg(markets.totals.over.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.totals ? (<div><div className="text-sm font-medium text-zinc-100">O {markets.totals.line}</div><div className="text-xs text-zinc-400">{formatOdds(markets.totals.over.price)}</div><div className={`text-xs ${getEdgeColor(markets.totals.over.edge)}`}>{formatEdge(markets.totals.over.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
        </div>
        <div className="grid grid-cols-[1fr,100px,100px,100px] gap-3 items-center">
          <div className="font-medium text-zinc-100 text-sm">{homeTeam}</div>
          <div className={`text-center py-2 px-2 rounded border ${markets.spreads ? getEdgeBg(markets.spreads.home.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.spreads ? (<div><div className="text-sm font-medium text-zinc-100">{formatSpread(markets.spreads.home.line)}</div><div className="text-xs text-zinc-400">{formatOdds(markets.spreads.home.price)}</div><div className={`text-xs ${getEdgeColor(markets.spreads.home.edge)}`}>{formatEdge(markets.spreads.home.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
          <div className={`text-center py-2 px-2 rounded border ${markets.h2h ? getEdgeBg(markets.h2h.home.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.h2h ? (<div><div className="text-sm font-medium text-zinc-100">{formatOdds(markets.h2h.home.price)}</div><div className={`text-xs ${getEdgeColor(markets.h2h.home.edge)}`}>{formatEdge(markets.h2h.home.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
          <div className={`text-center py-2 px-2 rounded border ${markets.totals ? getEdgeBg(markets.totals.under.edge) : 'bg-zinc-800/30 border-zinc-700/30'}`}>
            {markets.totals ? (<div><div className="text-sm font-medium text-zinc-100">U {markets.totals.line}</div><div className="text-xs text-zinc-400">{formatOdds(markets.totals.under.price)}</div><div className={`text-xs ${getEdgeColor(markets.totals.under.edge)}`}>{formatEdge(markets.totals.under.edge)}</div></div>) : <span className="text-zinc-600">-</span>}
          </div>
        </div>
      </div>
    </div>
  );
}

function TeamTotalsSection({ teamTotals, homeTeam, awayTeam }: { teamTotals: any; homeTeam: string; awayTeam: string }) {
  if (!teamTotals) {
    return (
      <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4">
        <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Team Totals</h2></div>
        <div className="p-8 text-center"><p className="text-zinc-500">No team totals available</p></div>
      </div>
    );
  }

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4">
      <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Team Totals</h2></div>
      <div className="p-4 space-y-3">
        {teamTotals.away && (
          <div className="grid grid-cols-[1fr,100px,100px] gap-3 items-center">
            <div className="font-medium text-zinc-100 text-sm">{awayTeam} <span className="text-zinc-500">({teamTotals.away.line})</span></div>
            <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(teamTotals.away.over.edge)}`}>
              <div className="text-xs text-zinc-400">Over</div>
              <div className="text-sm font-medium text-zinc-100">{formatOdds(teamTotals.away.over.price)}</div>
              <div className={`text-xs ${getEdgeColor(teamTotals.away.over.edge)}`}>{formatEdge(teamTotals.away.over.edge)}</div>
            </div>
            <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(teamTotals.away.under.edge)}`}>
              <div className="text-xs text-zinc-400">Under</div>
              <div className="text-sm font-medium text-zinc-100">{formatOdds(teamTotals.away.under.price)}</div>
              <div className={`text-xs ${getEdgeColor(teamTotals.away.under.edge)}`}>{formatEdge(teamTotals.away.under.edge)}</div>
            </div>
          </div>
        )}
        {teamTotals.home && (
          <div className="grid grid-cols-[1fr,100px,100px] gap-3 items-center">
            <div className="font-medium text-zinc-100 text-sm">{homeTeam} <span className="text-zinc-500">({teamTotals.home.line})</span></div>
            <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(teamTotals.home.over.edge)}`}>
              <div className="text-xs text-zinc-400">Over</div>
              <div className="text-sm font-medium text-zinc-100">{formatOdds(teamTotals.home.over.price)}</div>
              <div className={`text-xs ${getEdgeColor(teamTotals.home.over.edge)}`}>{formatEdge(teamTotals.home.over.edge)}</div>
            </div>
            <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(teamTotals.home.under.edge)}`}>
              <div className="text-xs text-zinc-400">Under</div>
              <div className="text-sm font-medium text-zinc-100">{formatOdds(teamTotals.home.under.price)}</div>
              <div className={`text-xs ${getEdgeColor(teamTotals.home.under.edge)}`}>{formatEdge(teamTotals.home.under.edge)}</div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function PlayerPropsSection({ props }: { props: any[] }) {
  if (!props || props.length === 0) {
    return (<div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4"><div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Player Props</h2></div><div className="p-8 text-center"><p className="text-zinc-500">No player props available</p></div></div>);
  }

  const grouped = props.reduce((acc: any, prop: any) => {
    const key = prop.market;
    if (!acc[key]) acc[key] = [];
    acc[key].push(prop);
    return acc;
  }, {});

  const marketLabels: Record<string, string> = {
    'pass tds': 'Passing TDs', 'pass yds': 'Passing Yards', 'rush yds': 'Rushing Yards',
    'receptions': 'Receptions', 'reception yds': 'Receiving Yards', 'anytime td': 'Anytime TD Scorer',
    'pass completions': 'Pass Completions', 'pass attempts': 'Pass Attempts', 'pass interceptions': 'Interceptions',
    'rush attempts': 'Rush Attempts', 'last td': 'Last TD Scorer', 'kicking points': 'Kicker Points',
    'field goals': 'Field Goals Made', 'tackles assists': 'Tackles + Assists',
  };

  return (
    <div className="space-y-4">
      {Object.entries(grouped).map(([market, marketProps]: [string, any]) => (
        <div key={market} className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800">
            <h2 className="font-semibold text-zinc-100">{marketLabels[market] || market}</h2>
          </div>
          <div className="p-4 space-y-2">
            {marketProps.map((prop: any, idx: number) => (
              <div key={idx} className="grid grid-cols-[1fr,100px,100px] gap-3 items-center py-2 border-b border-zinc-800/50 last:border-0">
                <div>
                  <div className="font-medium text-zinc-100 text-sm">{prop.player}</div>
                  {prop.line !== null && <div className="text-xs text-zinc-500">Line: {prop.line}</div>}
                </div>
                {prop.over && prop.under ? (
                  <>
                    <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(prop.over.edge)}`}>
                      <div className="text-xs text-zinc-400">Over</div>
                      <div className="text-sm font-medium text-zinc-100">{formatOdds(prop.over.price)}</div>
                      <div className={`text-xs ${getEdgeColor(prop.over.edge)}`}>{formatEdge(prop.over.edge)}</div>
                    </div>
                    <div className={`text-center py-2 px-2 rounded border ${getEdgeBg(prop.under.edge)}`}>
                      <div className="text-xs text-zinc-400">Under</div>
                      <div className="text-sm font-medium text-zinc-100">{formatOdds(prop.under.price)}</div>
                      <div className={`text-xs ${getEdgeColor(prop.under.edge)}`}>{formatEdge(prop.under.edge)}</div>
                    </div>
                  </>
                ) : prop.yes ? (
                  <div className={`text-center py-2 px-2 rounded border col-span-2 ${getEdgeBg(prop.yes.edge)}`}>
                    <div className="text-sm font-medium text-zinc-100">{formatOdds(prop.yes.price)}</div>
                    <div className={`text-xs ${getEdgeColor(prop.yes.edge)}`}>{formatEdge(prop.yes.edge)}</div>
                  </div>
                ) : null}
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function AlternatesSection({ alternates, homeTeam, awayTeam }: { alternates: any; homeTeam: string; awayTeam: string }) {
  if ((!alternates?.spreads?.length) && (!alternates?.totals?.length)) {
    return (<div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden mb-4"><div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Alternate Lines</h2></div><div className="p-8 text-center"><p className="text-zinc-500">No alternate lines available</p></div></div>);
  }

  const awaySpreads = alternates.spreads?.filter((s: any) => s.team === awayTeam).sort((a: any, b: any) => a.line - b.line) || [];
  const homeSpreads = alternates.spreads?.filter((s: any) => s.team === homeTeam).sort((a: any, b: any) => a.line - b.line) || [];
  const overs = alternates.totals?.filter((t: any) => t.type === 'Over').sort((a: any, b: any) => a.line - b.line) || [];
  const unders = alternates.totals?.filter((t: any) => t.type === 'Under').sort((a: any, b: any) => a.line - b.line) || [];

  return (
    <div className="space-y-4">
      {(awaySpreads.length > 0 || homeSpreads.length > 0) && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Alternate Spreads</h2></div>
          <div className="p-4 grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm text-zinc-400 mb-2">{awayTeam}</h3>
              <div className="grid grid-cols-3 gap-2">
                {awaySpreads.slice(0, 12).map((s: any, idx: number) => (
                  <div key={idx} className={`text-center py-2 px-2 rounded border ${getEdgeBg(s.edge)}`}>
                    <div className="text-sm font-medium text-zinc-100">{formatSpread(s.line)}</div>
                    <div className="text-xs text-zinc-400">{formatOdds(s.price)}</div>
                    <div className={`text-xs ${getEdgeColor(s.edge)}`}>{formatEdge(s.edge)}</div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm text-zinc-400 mb-2">{homeTeam}</h3>
              <div className="grid grid-cols-3 gap-2">
                {homeSpreads.slice(0, 12).map((s: any, idx: number) => (
                  <div key={idx} className={`text-center py-2 px-2 rounded border ${getEdgeBg(s.edge)}`}>
                    <div className="text-sm font-medium text-zinc-100">{formatSpread(s.line)}</div>
                    <div className="text-xs text-zinc-400">{formatOdds(s.price)}</div>
                    <div className={`text-xs ${getEdgeColor(s.edge)}`}>{formatEdge(s.edge)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
      {(overs.length > 0 || unders.length > 0) && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden">
          <div className="px-4 py-3 bg-zinc-800/50 border-b border-zinc-800"><h2 className="font-semibold text-zinc-100">Alternate Totals</h2></div>
          <div className="p-4 grid grid-cols-2 gap-4">
            <div>
              <h3 className="text-sm text-zinc-400 mb-2">Over</h3>
              <div className="grid grid-cols-3 gap-2">
                {overs.slice(0, 12).map((t: any, idx: number) => (
                  <div key={idx} className={`text-center py-2 px-2 rounded border ${getEdgeBg(t.edge)}`}>
                    <div className="text-sm font-medium text-zinc-100">O {t.line}</div>
                    <div className="text-xs text-zinc-400">{formatOdds(t.price)}</div>
                    <div className={`text-xs ${getEdgeColor(t.edge)}`}>{formatEdge(t.edge)}</div>
                  </div>
                ))}
              </div>
            </div>
            <div>
              <h3 className="text-sm text-zinc-400 mb-2">Under</h3>
              <div className="grid grid-cols-3 gap-2">
                {unders.slice(0, 12).map((t: any, idx: number) => (
                  <div key={idx} className={`text-center py-2 px-2 rounded border ${getEdgeBg(t.edge)}`}>
                    <div className="text-sm font-medium text-zinc-100">U {t.line}</div>
                    <div className="text-xs text-zinc-400">{formatOdds(t.price)}</div>
                    <div className={`text-xs ${getEdgeColor(t.edge)}`}>{formatEdge(t.edge)}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

interface GameDetailClientProps {
  gameData: { id: string; homeTeam: string; awayTeam: string; sportKey: string; };
  bookmakers: Record<string, any>;
  availableBooks: string[];
  availableTabs?: { fullGame?: boolean; firstHalf?: boolean; secondHalf?: boolean; q1?: boolean; q2?: boolean; q3?: boolean; q4?: boolean; props?: boolean; alternates?: boolean; teamTotals?: boolean; };
}

export function GameDetailClient({ gameData, bookmakers, availableBooks, availableTabs }: GameDetailClientProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('full');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const priorityOrder = ['fanduel', 'draftkings', 'betmgm', 'williamhill_us', 'betrivers'];
  const sortedBooks = [...availableBooks].sort((a, b) => {
    const aIndex = priorityOrder.indexOf(a);
    const bIndex = priorityOrder.indexOf(b);
    if (aIndex === -1 && bIndex === -1) return 0;
    if (aIndex === -1) return 1;
    if (bIndex === -1) return -1;
    return aIndex - bIndex;
  });

  const [selectedBook, setSelectedBook] = useState(sortedBooks[0] || '');

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) setIsOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const selectedConfig = BOOK_CONFIG[selectedBook] || { name: selectedBook, color: '#6b7280' };
  const marketGroups = bookmakers[selectedBook]?.marketGroups || {};

  const BookIcon = ({ bookKey, size = 24 }: { bookKey: string; size?: number }) => {
    const config = BOOK_CONFIG[bookKey] || { name: bookKey, color: '#6b7280' };
    const initials = config.name.split(' ').map(w => w[0]).join('').slice(0, 2);
    return (<div className="rounded flex items-center justify-center font-bold text-white flex-shrink-0" style={{ backgroundColor: config.color, width: size, height: size, fontSize: size * 0.4 }}>{initials}</div>);
  };

  const tabs = [
    { key: 'full', label: 'Full Game', available: true },
    { key: '1h', label: '1st Half', available: availableTabs?.firstHalf },
    { key: '2h', label: '2nd Half', available: availableTabs?.secondHalf },
    { key: '1q', label: '1Q', available: availableTabs?.q1 },
    { key: '2q', label: '2Q', available: availableTabs?.q2 },
    { key: '3q', label: '3Q', available: availableTabs?.q3 },
    { key: '4q', label: '4Q', available: availableTabs?.q4 },
    { key: 'team', label: 'Team Totals', available: availableTabs?.teamTotals },
    { key: 'props', label: 'Player Props', available: availableTabs?.props },
    { key: 'alt', label: 'Alt Lines', available: availableTabs?.alternates },
  ].filter(tab => tab.available);

  return (
    <div>
      <div className="relative mb-6" ref={dropdownRef}>
        <button onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-3 px-4 py-2.5 bg-zinc-800 border border-zinc-700 rounded-lg hover:bg-zinc-700/70 transition-all min-w-[200px]">
          <BookIcon bookKey={selectedBook} size={28} />
          <span className="font-medium text-zinc-100">{selectedConfig.name}</span>
          <svg className={`w-4 h-4 text-zinc-400 ml-auto transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
        </button>
        {isOpen && (
          <div className="absolute z-50 mt-2 w-64 bg-zinc-800 border border-zinc-700 rounded-lg shadow-xl overflow-hidden">
            <div className="max-h-80 overflow-y-auto">
              {sortedBooks.map((book) => {
                const config = BOOK_CONFIG[book] || { name: book, color: '#6b7280' };
                const isSelected = book === selectedBook;
                return (<button key={book} onClick={() => { setSelectedBook(book); setIsOpen(false); }} className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-all ${isSelected ? 'bg-emerald-500/10 text-emerald-400' : 'hover:bg-zinc-700/50 text-zinc-300'}`}><BookIcon bookKey={book} size={28} /><span className="font-medium">{config.name}</span>{isSelected && (<svg className="w-4 h-4 ml-auto text-emerald-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>)}</button>);
              })}
            </div>
          </div>
        )}
      </div>

      {tabs.length > 1 && (
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {tabs.map((tab) => (<button key={tab.key} onClick={() => setActiveTab(tab.key)} className={`px-4 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${activeTab === tab.key ? 'bg-zinc-700 text-zinc-100' : 'bg-zinc-800/50 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-300'}`}>{tab.label}</button>))}
        </div>
      )}

      {activeTab === 'full' && <MarketSection title="Full Game" markets={marketGroups.fullGame} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '1h' && <MarketSection title="1st Half" markets={marketGroups.firstHalf} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '2h' && <MarketSection title="2nd Half" markets={marketGroups.secondHalf} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '1q' && <MarketSection title="1st Quarter" markets={marketGroups.q1} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '2q' && <MarketSection title="2nd Quarter" markets={marketGroups.q2} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '3q' && <MarketSection title="3rd Quarter" markets={marketGroups.q3} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === '4q' && <MarketSection title="4th Quarter" markets={marketGroups.q4} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === 'team' && <TeamTotalsSection teamTotals={marketGroups.teamTotals} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
      {activeTab === 'props' && <PlayerPropsSection props={marketGroups.playerProps} />}
      {activeTab === 'alt' && <AlternatesSection alternates={marketGroups.alternates} homeTeam={gameData.homeTeam} awayTeam={gameData.awayTeam} />}
    </div>
  );
}